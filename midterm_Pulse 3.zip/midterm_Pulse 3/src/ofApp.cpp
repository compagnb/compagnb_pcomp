#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    #ifdef TARGET_OPENGLES
        shaderBlurX.load("shadersES2/shaderBlurX");
        shaderBlurY.load("shadersES2/shaderBlurY");
    #else
        if(ofIsGLProgrammableRenderer()){
            shaderBlurX.load("shadersGL3/shaderBlurX");
            shaderBlurY.load("shadersGL3/shaderBlurY");
        }else{
            shaderBlurX.load("shadersGL2/shaderBlurX");
            shaderBlurY.load("shadersGL2/shaderBlurY");
        }
    #endif

    //fix that mac shit
	ofSetVerticalSync(true);
	
	//set up boolean for serial data
	bSendSerialMessage = false;
	ofSetLogLevel(OF_LOG_VERBOSE);
	
    //load my font
	font.loadFont("DIN.otf", 64);
	
    //list my serial devices...
	serial.listDevices();
	vector <ofSerialDeviceInfo> deviceList = serial.getDeviceList();
    
    //define feedback speed from arduino and connect to my port
    int baud = 9600;
	//serial.setup(0, baud);//open the first device
    serial.setup("/dev/tty.usbmodem1411", baud); // mac osx example

    //getting info...
    nTimesRead = 0;
	nBytesRead = 0;
	readTime = 0;
	memset(bytesReadString, 0, 4);
    str = "";
    fullPacket = "";
    
    //set size to window
    width = ofGetWidth();
    height = ofGetHeight();
    
    //initialize screengrabber and shader
    video.initGrabber(width, height, true);
    fboBlurOnePass.allocate(width, height);
    fboBlurTwoPass.allocate(width, height);
    
    
    //set framerate
    ofSetFrameRate(30);
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    do {
        str = ofxGetSerialString(serial,'\n'); //read until end of line
        if (str=="") continue;
        numbersAsStrings=ofSplitString(str, ",");
        // cout << str;
    
    } while (str!="");
    //cout << fullPacket;
    //use fullPacket for below...
    //figure out how take this string and split it into an 11-cell array with the individual values inside of it
    //use fullPacket for below...
    //figure out how take this string and split it into an 11-cell array with the individual values inside of it
    
    for( int i = 0; i < numbersAsStrings.size(); i++){
        //separates number into channel
        if (i == 0){
            heartRate = ofToInt(numbersAsStrings[i]);
            cout << heartRate;
        }
        
    }
    
    fullPacket = "";

    video.update();
}

//--------------------------------------------------------------
string ofApp::ofxGetSerialString(ofSerial &serial, char until) {
    static string str;
    stringstream ss;
    char ch;
    int ttl=1000;
    while ((ch=serial.readByte())>0 && ttl-->0 && ch!=until) {
        ss << ch;
    }
    str+=ss.str();
    if (ch==until) {
        string tmp=str;
        str="";
        return ofxTrimString(tmp);
    } else {
        return "";
    }
    
}

// trim trailing spaces Right
//--------------------------------------------------------------
string ofApp::ofxTrimStringRight(string str) {
    size_t endpos = str.find_last_not_of(" \t\r\n");
    return (string::npos != endpos) ? str.substr( 0, endpos+1) : str;
}

// trim trailing spaces Left
//--------------------------------------------------------------

string ofApp::ofxTrimStringLeft(string str) {
    size_t startpos = str.find_first_not_of(" \t\r\n");
    return (string::npos != startpos) ? str.substr(startpos) : str;
}

// trim trailing spaces All Left and Right
//--------------------------------------------------------------

string ofApp::ofxTrimString(string str) {
    return ofxTrimStringLeft(ofxTrimStringRight(str));;
}



//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
    
//    if (nBytesRead > 0 && ((ofGetElapsedTimef() - readTime) < 0.5f)){
//		ofSetColor(0);
//	} else {
//		ofSetColor(220);
//	}
	
    ofSetColor(0);
    float blur = ofMap(heartRate, 0, ofGetWidth(), 0, 10, true);
    
    //----------------------------------------------------------
    fboBlurOnePass.begin();
    
    shaderBlurX.begin();
    shaderBlurX.setUniform1f("blurAmnt", blur);
    
    video.draw(0, 0);
    
    shaderBlurX.end();
    
    fboBlurOnePass.end();
    
    //----------------------------------------------------------
    fboBlurTwoPass.begin();
    
    shaderBlurY.begin();
    shaderBlurY.setUniform1f("blurAmnt", blur);
    
    fboBlurOnePass.draw(0, 0);
    
    shaderBlurY.end();
    
    fboBlurTwoPass.end();
    
    //----------------------------------------------------------
    ofSetColor(ofColor::white);
    fboBlurTwoPass.draw(0, 0);

    
    string msg;
    msg += "(Heart Rate " + ofToString(heartRate, 3) + ")";
    ofSetColor(200, 0, 200);
    font.drawString(msg, 50, 100);

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    //bSendSerialMessage = true;

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
